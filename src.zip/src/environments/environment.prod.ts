export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyAxg5NhTfds6NYc1l0Tw1TXEv_7YOeoOKM',
    authDomain: 'chatbot-7ee16.firebaseapp.com',
    databaseURL: 'https://chatbot-7ee16.firebaseio.com',
    projectId: 'chatbot-7ee16',
    storageBucket: 'chatbot-7ee16.appspot.com',
    messagingSenderId: '551351756877',
    appId: "1:551351756877:web:b9d300e365d44c9dfdd404",
  measurementId: "G-0E7YQJLNKN"
  }
};
