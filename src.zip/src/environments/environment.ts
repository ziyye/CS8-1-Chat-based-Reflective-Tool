// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.


export const environment = {
  production: false,
  firebase: {
    apiKey: 'AIzaSyAxg5NhTfds6NYc1l0Tw1TXEv_7YOeoOKM',
    authDomain: 'chatbot-7ee16.firebaseapp.com',
    databaseURL: 'https://chatbot-7ee16.firebaseio.com',
    projectId: 'chatbot-7ee16',
    storageBucket: 'chatbot-7ee16.appspot.com',
    messagingSenderId: '551351756877',
    appId: "1:551351756877:web:b9d300e365d44c9dfdd404",
  measurementId: "G-0E7YQJLNKN"
  }
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
