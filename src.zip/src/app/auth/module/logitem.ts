export interface LogItem { 
    id?:any;
    names?:string;
    problems?:string;
 
  }
  