export interface Notification { 
    names?:string,
    id?:any,
    problems?:string,
    date?:Date,
    state?:string
 
}